Contributor(s): Borys�aw Paulewicz, bpaulewicz@swps.edu.pl, Micha� Wierzcho�, mwierzchon@gmail.com, Marta Siedlecka, siedlecka.marta@gmail.com

Citation: unpublished

Stimulus: The Gabor patches and the mask were presented on a light
grey background. on LCD monitors (1280 x 800 resolution. 60-Hz refresh
rate). Presentation times of the stimuli were synchronized with the
vertical refresh rate of the screen. The size of the stimuli was 3.34
degrees of visual angle. Gabors were oriented at 45 degrees left or
right and their parameters were constant (contrast = 30%. frequency =
20 cpd. sigma of the Gaussian envelope = 30 pixels). The mask
consisted of six grey coaxial circles.

Confidence scale: The PAS scale was presented with the question: 'How
clear your experience of stimulus was?' and the options were: �no
experience�, �a vague experience�, �an almost clear experience�, and
�clear experience�. Participants were asked to indicate their response
with a mouse click.

Manipulations: The stimuli and the mask were presented on a light grey
background. The size of the stimuli was 2 degrees of visual
angle. Gabor patches were oriented at 45 degrees left or right and
their parameters were constant (contrast = 30%, frequency = 20
cpd. sigma of the Gaussian envelope = 30 pixels). Backward mask was a
Gaussian vignetted checkerboard and had the same parameters as Gabor
patch. The subjective scale appeared always before the decision. All
trials began with fixation cross (1000ms) and then the Gabor patch was
presented for a variable duration (16ms, 32ms, 64ms and 128ms,
intermixed randomly) and was immediately replaced by the mask. Mask
was presented for minimum duration of 200ms before discrimination task
or awareness scale appeared and it lasted until participant
responded. In a discrimination task participants had to respond
whether the Gabor patch is oriented toward right of left side using
left or right arrow on the keyboard. The main manipulation was a
within subject manipulation of time between the stimulus onset and an
appearance of the awareness scale. There were two time conditions in
which the scale appeared either 328ms or 1000ms (Condition variable)
after the stimuli onset.

Block size: The task consisted of 8 experimental blocks with 32 trials
each. The trials with the same time condition were blocked and
balanced, so a participant either started with four blocks in 328ms
condition or 1000ms condition.

Feedback: No

NaN fields: deadline on the response

Subject population: 31 students of Jagiellonian University (4 males),
aged 19-23 (M = 20.09, SD = 1.04) took part in the study in exchange
for course credits. All participants had normal or corrected-to-normal
vision. Participants gave informed written consents to experimental
procedure.

Response device: keyboard, mouse

Experiment setting: lab

Training: 2 blocks of 16 trials of practice sessions, no data.

Experiment goal: SOA effect.

Main result: The accuracy - rating logistic regression slope was
higher for SOA 328ms than 1000ms for presentation time 16ms.

Special instructions: Discrimination task required from participants
to decide whether a target stimulus was oriented left or right as
quick as possible and with maximal accuracy.

Experiment dates: 2014 04

Location of data collection: Jagiellonian University, Krakow, Poland

Additional information: Reaction Time data for the confidence ratings was not collected
